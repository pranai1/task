import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})
export class MainComponent implements OnInit {
  isActive:boolean = false;
  isOpen:boolean = false;
  feature_products:any[] = [];
  main_products:any[] = [];
  constructor() { }

  ngOnInit(): void {
    this.feature_products = [
      {
       quantity:4
      },
      {
        quantity:4
      }
    ]
    this.main_products = [
      {
       quantity:4,
       out_of_stock:false,
       warning:false,
       available:true
      },
      {
        quantity:4,
        out_of_stock:false,
        warning:true,
        available:false
      },
      {
        quantity:4,
        out_of_stock:true,
        warning:false,
        available:false
       },
       {
        quantity:4,
        out_of_stock:false,
       warning:false,
       available:true
       },
       {
        quantity:4,
        out_of_stock:false,
        warning:false,
        available:true
       },
       {
        quantity:4,
        out_of_stock:false,
        warning:false,
        available:true
       },
       {
        quantity:4,
        out_of_stock:false,
        warning:false,
        available:true
       },
       {
        quantity:4,
        out_of_stock:false,
        warning:false,
        available:true
       },
       {
        quantity:4,
        out_of_stock:false,
        warning:false,
        available:true
       },

           {
       quantity:4,
       out_of_stock:false,
       warning:false,
       available:true
      },
      {
        quantity:4,
        out_of_stock:false,
        warning:false,
        available:true
       },

           {
       quantity:4,
       out_of_stock:false,
       warning:false,
       available:true
      },
      {
        quantity:4,
        out_of_stock:false,
       warning:false,
       available:true
       },
    ]
  }

  SortBy(){
    this.isActive = !this.isActive;
    this.isOpen = !this.isOpen;
  }

  decrease(i:number){
    if(this.feature_products[i].quantity > 0)
    this.feature_products[i].quantity--;
  }

  increase(i:number){
    this.feature_products[i].quantity++;
  }
  decreaseMain(i:number){
    if(this.main_products[i].quantity > 0)
    this.main_products[i].quantity--;
  }

  increaseMain(i:number){
    this.main_products[i].quantity++;
  }
}
